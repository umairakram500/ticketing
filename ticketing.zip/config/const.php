<?php

return [

    'terminal_types' => [
        1 => 'Main Terminal',
        2 => 'Sub Terminal',
        3 => 'Stop'
    ]

];
